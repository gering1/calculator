import logo from './logo.svg';
import './App.css';
import Number from './Components/Number'
function App() {
  return (
    <div className="App">
    <Number></Number>
    </div>
  );
}

export default App;

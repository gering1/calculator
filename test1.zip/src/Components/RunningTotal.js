import React from 'react'

function RunningTotal(props) {
    return (
        <div>
           <text>{props.val}</text>
        </div>
    )
}

export default RunningTotal

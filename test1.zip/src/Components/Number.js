import React, {useState, useEffect} from 'react'
import { makeStyles} from '@material-ui/core/styles';
import RunningTotal from './RunningTotal';
import button from '@material-ui/core/button'
import io from 'socket.io-client'

import Paper from '@material-ui/core/Paper'
import Calculations from './Calculations'
const row1 = [7,8,9]
const row2 = [4,5,6]
const row3 = [1,2,3]
const row4 = [0]
const operators = ["=","+","-","*","/"]
const useStyles = makeStyles(theme => ({
    root: {
        width: "30%",
        backgroundColor: "rgba(0, 0, 0, 0.54) ",
        margin: "auto",
        marginTop: "20px",
       padding: "20px",
        display: "flex",
        justifyContent: "center",
        flexDirection: "column"
    },
    number_button : {
        backgroundColor: "#64b5f6"
    },
 
    operator_button: {
        backgroundColor: "#ffb74d"
    },
    inner: {
       
    },
    row_container : {
        
    },
    row: {
       
    },
    operator_container: {
        
    }

}))
function Number() {
    const classes = useStyles()
    const [calculations, setCalculations] = useState([])
    const [currentNum, setNum] = useState("0")
    const [firstNum, setFirstNum] = useState(null)
    const [needsSecondNum, setNeedsSecondNum] = useState(false)
    const [secondNum, setSecondNum] = useState(0)
    const [calcCompleted, setCalcCompleted] = useState(false)
    const [currentOperator,setCurrentOperator] = useState("")

    const socket = io('http://127.0.0.1:5000/')
    const setCurrentNum = (num) => {
        if(needsSecondNum) { //this means we have reached an operator, so the current number clicked will become the current number seen
            setNum(String(num))

            setNeedsSecondNum(false)
        }
        else {
            console.log(currentOperator)
            if (currentOperator === "=") {
              console.log('test')
               setCurrentOperator("")
               setNum(num) 
               return
            }
            currentNum == 0 ? setNum(num) : setNum(currentNum + num) //if it is first number clicked, replace the 0 with number, else add to end of num
          
        }
        
    }
    useEffect(() => {
        socket.on('calculation_made', calculation => {
            setCalculations(calculations => [calculation, ...calculations])
        })
    },[])
    const calculateNums = (fn,sn,op )=>  {
        let res = 0
        switch(op) {
            case '+': 
                return fn + sn
            case '-':
                return fn - sn
            case '*':
                return fn * sn
            case '/':
                return fn/ sn
            default: //if the operator is "=", just return the second number
                return sn
        }
        
    }
    const clearNums = () => {
        
    }

 
    const handleOperator = (op) => {
        let val = parseFloat(currentNum)
        setCalcCompleted(false)
        if(currentOperator && needsSecondNum)  { //2 operators inputted consecutively
           setCurrentOperator(op)
           return
        }
        if(firstNum === null) { //set first number 
            setFirstNum(val)
            
        }
        else if(currentOperator) { //if operator has been set, we need to store previous calculation
            let res = calculateNums(firstNum,val,currentOperator)
                if(calculations.length === 10) {
                    calculations.pop()
         
            } 

            setCalculations(calculations => [[firstNum,currentOperator,currentNum,"=",res],...calculations])
            console.log('test')
            socket.emit('calculation_made',[firstNum,currentOperator,currentNum,"=",res])
            socket.emit('test')
            setCalcCompleted(true)
            setNum(String(res))
            setFirstNum(res)
            
            
        }
        setNeedsSecondNum(true)  
        setCurrentOperator(String(op))
      
    }

    return (
        <>
        <Paper className = {classes.root} >
          
        <div className = {classes.inner}>
           <p>{currentNum}</p>
        </div>
        <div className = {classes.operator_container}>
            {
            operators.map(operator => (
                [
                <button className = {classes.operator_button} id = {operator} onClick = {e => handleOperator(e.target.id)}>{operator}</button>
                ]
            ))
        }
      
        </div>
        <div className = {classes.row_container}>
            <div className = {classes.row}>
                {
                row1.map(num => (
                    [
                        <button className = {classes.number_button} id = {num} onClick = {e => setCurrentNum(e.target.id)}>{num}</button>
                    ]
                ))
                }
            </div>
            <div className = {classes.row}>
                {
                row2.map(num => (
                    [
                        <button className = {classes.number_button}id = {num} onClick = {e => setCurrentNum(e.target.id)}>{num}</button>
                    ]   
                ))
                }
            </div>
            <div className = {classes.row}>
                {
                row3.map(num => (
                    [
                        <button className = {classes.number_button}id = {num} onClick = {e => setCurrentNum(e.target.id)}>{num}</button>
                    ]
                ))
                }
            </div>
            <div className = {classes.row}>
                {
                row4.map(num => (
                    [
                        <button className = {classes.number_button}id = {num} onClick = {e => setCurrentNum(e.target.id)}>{num}</button>
                    ]
                ))
                }
            </div>
            </div>
     
     </Paper>
     <>
     <Calculations calculations = {calculations}></Calculations>
    </> 
    </>

       
    )
}

export default Number


import React from 'react'
import MenuItem from '@material-ui/core/MenuItem'
import { makeStyles} from '@material-ui/core/styles';

import MenuList from '@material-ui/core/MenuList'
import { Menu } from '@material-ui/core'

const useStyles = makeStyles(theme => ({
   container: {
       display: "flex",
       justifyContent: "center"
   }
}))
export default function Calculations(props) {
    const classes = useStyles()
    return (
        <div className = {classes.container}>
            <MenuList className = {classes.calculations_list}>
            {
                
            props.calculations.map(calculation => (
            [
                
               <MenuItem>{calculation}</MenuItem>
              
            ]

    ))
            }
            </MenuList>
          
        </div>
    )
}


